<?php $__env->startSection('content'); ?>
    <div class="container" xmlns="http://www.w3.org/1999/html">


        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <!----------------------------------------------------Recette /Depences -------------------------------------->


            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="panel panel-info ">
                        <div class="panel-heading">Recettes/Dépences</div>
                        <div class="panel-body">
                            <form action="SaveRecette" method="post">
                            <div class="row">
                                    <?php echo e(csrf_field()); ?>


                                <div class="col-lg-4">
                                    <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">N°</button>
                                </span>
                                        <input autofocus maxlength="8" tabindex="2" onkeyup='this.value=this.value.toUpperCase()' required id="NUMERO" name="NUMERO" type="text" class="form-control" placeholder="">
                                    </div><!-- /input-group -->
                                </div><!-- /.col-lg-6 -->

                                    <div class="col-lg-4">
                                        <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Date</button>
                                </span>
                                            <input   tabindex="1"  required id="DATE" name="DATE" value="<?php  echo date('Y-m-d'); ?>" type="date" class="form-control">
                                        </div><!-- /input-group -->
                                    </div><!-- /.col-lg-6 -->



                                    <div class="col-lg-4">
                                        <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Type</button>
                                </span>
                                            <select   required id="TYPE_PAYEMENT" name="TYPE_PAYEMENT"  class="form-control">
                                                <option value="1">Recette</option>
                                                <option value="2">Dépence</option>
                                            </select>
                                        </div><!-- /input-group -->
                                    </div><!-- /.col-lg-6 -->

                            </div><!-- /.row -->

                                <br>

                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Etudiant</button>
                                </span>
                                            <select   required id="ETUDIANT" name="ETUDIANT"  class="form-control">
                                                <option value="0">Aucun</option>
                                                <?php $__currentLoopData = $AllEtudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MP): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <option value="<?php echo e($MP->id); ?>"><?php echo e($MP->NOM_ETUDIANT); ?> <?php echo e($MP->PRENOM_ETUDIANT); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                            </select>

                                        </div><!-- /input-group -->
                                    </div><!-- /.col-lg-6 -->
                                    <div class="col-lg-4">
                                        <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Préstataire</button>
                                </span>
                                            <select    id="PRESTATAIRE" name="PRESTATAIRE"  class="form-control">
                                                <option value="0">Aucun</option>
                                                <?php $__currentLoopData = $AllPrestataires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MP): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <option value="<?php echo e($MP->id); ?>"><?php echo e($MP->NOM); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                            </select>

                                        </div><!-- /input-group -->
                                    </div><!-- /.col-lg-6 -->
                                    <div class="col-lg-4">
                                        <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Entreprise</button>
                                </span>
                                            <select   required id="ENTREPRISE" name="ENTREPRISE"  class="form-control">
                                                <option value="0">Aucun</option>
                                                <?php $__currentLoopData = $AllCompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MP): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <option value="<?php echo e($MP->id); ?>"><?php echo e($MP->NOM); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                            </select>

                                        </div><!-- /input-group -->
                                    </div><!-- /.col-lg-6 -->
                                </div><!-- /.row -->




                                <br>
                                <div class="row">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="col-lg-4">
                                        <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Mode</button>
                                </span>

                                            <select   required id="MODE_PAYEMENT" name="MODE_PAYEMENT"  class="form-control">
                                                <?php $__currentLoopData = $AllModePayement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MP): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                <option value="<?php echo e($MP->id); ?>"><?php echo e($MP->LIBELLE); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                            </select>
                                        </div><!-- /input-group -->
                                    </div><!-- /.col-lg-6 -->

                                    <div class="col-lg-4">
                                        <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Bénéficier</button>
                                </span>
                                            <input list="Liste_BENEFICIER"   required id="BENEFICIER" name="BENEFICIER" type="text" class="form-control" placeholder="">
                                            <datalist id="Liste_BENEFICIER">

                                                <?php $__currentLoopData = $AllEtudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $E): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <!--<option value="Meteor">-->
                                                    <option value="<?php echo e($E->id); ?>"><?php echo e($E->NOM_ETUDIANT); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                <?php $__currentLoopData = $AllCompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $C): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                        <!--<option value="Meteor">-->
                                                <option value="<?php echo e($C->id); ?>"><?php echo e($C->NOM); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                            </datalist>
                                        </div><!-- /input-group -->
                                    </div><!-- /.col-lg-6 -->

                                    <div class="col-lg-4">
                                        <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Session</button>
                                </span>
                                            <select   required id="TYPE_PAYEMENT" name="TYPE_PAYEMENT"  class="form-control">
                                                <option value="1">Recette</option>
                                                <option value="2">Dépence</option>
                                            </select>
                                        </div><!-- /input-group -->
                                    </div><!-- /.col-lg-6 -->

                                </div><!-- /.row -->



                            </form>

                        </div>
                    </div>
                </div>
            </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>