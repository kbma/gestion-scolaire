<?php $__env->startSection('content'); ?>
    <div class="container">


        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                        <li><a href="#">Sociétés</a></li>
                        <li class="active">Liser les sociétés</li>
                    </ol>
                </div>
            </div>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-info ">
                    <div class="panel-heading"><strong>Liste des societes:</strong> <span class="badge"><?php echo e(\App\Company::count()); ?> societe(s)</span> <a style="float: right" href="<?php echo e(route('AddCompany')); ?>" title="Ajouter une nouvelle societe" class="glyphicon glyphicon-plus-sign"></a> </div>
                    <div class="panel-body">

                        <div class="row">
                            <div class="col-lg-12">
                                <table class="table table-striped table-responsive" >
                                    <tr>
                                        <th>Code</th>
                                        <th>NOM</th>
                                        <th>Tél</th>

                                        <th colspan="4">Actions</th>
                                    </tr>
                                    <?php $__currentLoopData = $AllCompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CF): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr id="<?php echo e($CF->id); ?>">
                                        <td> <?php echo e($CF->CODE); ?><d>

                                        <td><?php echo e($CF->NOM); ?></td>
                                        <td><?php echo e($CF->TEL); ?></td>

                                        <td> <?php echo ($CF->ACTIVE ==1) ? '<a href="'.route('DisableCompany',$CF->id).'"><span  class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>' : '<a href="'.route('EnableCompany',$CF->id).'"><span  class="glyphicon glyphicon-eye-close" aria-hidden="true"></span></a>'; ?></td>
                                        <td  data-toggle="modal" data-target="#ModalDetails<?php echo e($CF->id); ?>" data-whatever="@mdo" ><span title="Détails" class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"></span></td>
                                        <td  data-toggle="modal" data-target="#ModalEdit<?php echo e($CF->id); ?>" data-whatever="@mdo" ><span title="Modifier" class="glyphicon glyphicon-edit" aria-hidden="true"></span></td>
                                        <td  data-toggle="modal" data-target="#ModalDel<?php echo e($CF->id); ?>" data-whatever="@mdo" ><span title="Supprimer" class="glyphicon glyphicon-remove" aria-hidden="true"></span></td>


                                        <!----------->
                                        <div class="modal fade" id="ModalDetails<?php echo e($CF->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                                            <div class="modal-dialog" role="document">

                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                            <h4 class="modal-title" id="exampleModalLabel">Détails du préstataire  N°<?php echo e($CF->id); ?></h4>
                                                        </div>
                                                        <div class="modal-body">

                                                            <div class="form-group">
                                                                <label for="recipient-name" class="control-label">Adresse:</label>
                                                                <input disabled required onkeyup='this.value=this.value.toUpperCase()' type="text" class="form-control" value="<?php echo e($CF->ADRESSE); ?>">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="recipient-name" class="control-label">VILLE:</label>
                                                                <input disabled required onkeyup='this.value=this.value.toUpperCase()' type="text" class="form-control" name="CODE" id="CODE" value="<?php echo e($CF->VILLE); ?>">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="message-text" class="control-label">CP:</label>
                                                                <input disabled required style="text-transform: capitalize" type="text" class="form-control"  value="<?php echo e($CF->CP); ?>">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="message-text" class="control-label">Email:</label>
                                                                <input disabled required style="text-transform: capitalize" type="text" class="form-control" name="EMAIL" id="EMAIL" value="<?php echo e($CF->EMAIL); ?>">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="message-text" class="control-label">Observation:</label>
                                                                <input disabled required style="text-transform: capitalize" type="text" class="form-control" name="OBSERVATION" id="OBSERVATION" value="<?php echo e($CF->OBSERVATION); ?>">
                                                            </div>
                                                        </div>

                                                    </div>

                                            </div>
                                        </div>
                                        <!----------->
                                        <div class="modal fade" id="ModalEdit<?php echo e($CF->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                                            <div class="modal-dialog" role="document">
                                                <form action="UpdateCompany" method="post" name="CAT<?php echo e($CF->id); ?> " id="CAT<?php echo e($CF->id); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" id="id" value="<?php echo e($CF->id); ?>">
                                                    <div class="modal-content">
                                                    <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                        <h4 class="modal-title" id="exampleModalLabel">Modifier societe N°<?php echo e($CF->id); ?></h4>
                                                    </div>
                                                    <div class="modal-body">
                                                            <div class="form-group">
                                                                <label for="recipient-name" class="control-label">CODE:</label>
                                                                <input required onkeyup='this.value=this.value.toUpperCase()' type="text" class="form-control" name="CODE" id="CODE" value="<?php echo e($CF->CODE); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="message-text" class="control-label">NOM:</label>
                                                                <input required style="text-transform: capitalize" type="text" class="form-control" name="NOM" id="NOM" value="<?php echo e($CF->NOM); ?>">
                                                            </div>



                                                        <div class="form-group">
                                                            <label for="message-text" class="control-label">ADRESSE:</label>
                                                            <input required style="text-transform: capitalize" type="text" class="form-control" name="ADRESSE" id="ADRESSE" value="<?php echo e($CF->ADRESSE); ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="message-text" class="control-label">VILLE:</label>
                                                            <input required style="text-transform: capitalize" type="text" class="form-control" name="VILLE" id="VILLE" value="<?php echo e($CF->VILLE); ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="message-text" class="control-label">CP:</label>
                                                            <input required style="text-transform: capitalize" type="text" class="form-control" name="CP" id="CP" value="<?php echo e($CF->CP); ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="message-text" class="control-label">TEL:</label>
                                                            <input required style="text-transform: capitalize" type="text" class="form-control" name="TEL" id="TEL" value="<?php echo e($CF->TEL); ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="message-text" class="control-label">EMAIL:</label>
                                                            <input required style="text-transform: capitalize" type="text" class="form-control" name="EMAIL" id="EMAIL" value="<?php echo e($CF->EMAIL); ?>">
                                                        </div>



                                                        <div class="form-group">
                                                            <label for="message-text" class="control-label">Observation:</label>
                                                            <input required style="text-transform: capitalize" type="text" class="form-control" name="OBSERVATION" id="OBSERVATION" value="<?php echo e($CF->OBSERVATION); ?>">
                                                        </div>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <button  class="btn btn-default"  data-dismiss="modal">Fermer</button>
                                                        <button  onclick="$('#CAT<?php echo $CF->id; ?> ').submit()"  class="btn btn-primary">Enregistrer</button>
                                                    </div>
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                        <!----------->
                                        <!----------->
                                        <div class="modal fade" id="ModalDel<?php echo e($CF->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                                            <div class="modal-dialog" role="document">
                                                <form action="DelCompany" method="post" name="CATDel<?php echo e($CF->id); ?> " id="CAT<?php echo e($CF->id); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" id="id" value="<?php echo e($CF->id); ?>">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                            <h4 class="modal-title" id="exampleModalLabel">Supprimer societe N°<?php echo e($CF->id); ?></h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Voulez vous vraiment supprimer cette societe?</p>



                                                        </div>
                                                        <div class="modal-footer">
                                                            <input type="reset" class="btn btn-default" value="Fermer" data-dismiss="modal">
                                                            <input type="submit" onclick="$('#CATDel<?php echo $CF->id; ?> ').submit()"  class="btn btn-danger" value="Supprimer"/>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        <!----------->
                                    </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                </table>
                                <?php echo e($AllCompany->links()); ?>


                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>