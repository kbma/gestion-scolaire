<?php $__env->startSection('content'); ?>




    <div class="container">

        <?php if(Session::has('msg')): ?>
            <div class="alert alert-success">
                <ul>
                    <?php echo e(Session::get("msg")); ?>

                </ul>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                    <li><a href="#">Clients</a></li>
                    <li class="active">Liser les étudiants</li>
                </ol>
            </div>
        </div>



    <div class="row">
        <div class="col-md-12">

        <form  action="<?php echo e(route('SearchStudent')); ?>">
            <div class="col-md-6">
                <div class="form-group">
                    <input value="<?php echo e(isset($_GET['key'])?$_GET['key']:''); ?>" type="text" id="key" name="key" class="form-control" placeholder="Nom,Prénom,Matricule">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <button type="submit" class="btn btn-default">Chercher</button>

                </div>
            </div>
        </form>
        </div>
    </div>

        <!--------------------------------------------------------------------------->
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-info ">
                    <div class="panel-heading"><strong>Liste des etudiants:</strong> <span class="badge"><?php echo e(\App\Etudiant::count()); ?> etudiant(s)</span> <a style="float: right" href="<?php echo e(route('AddStudent')); ?>" title="Ajouter un etudiant" class="glyphicon glyphicon-plus-sign"></a> </div>
                    <div class="panel-body">

                        <div class="row">
                            <div class="col-lg-12">


                                <table class="table table-striped table-responsive" >
                                    <tr>
                                        <th>D.inscription</th>
                                        <th>Matricule</th>
                                        <th>CIN / Passport</th>
                                        <th>Nom</th>
                                        <th>Prénom</th>
                                        <th>Tel</th>

                                      <!--  <th>Lieu</th>
                                        <th>CIN.Passport</th>
                                        <th>Ville</th>
                                        <th>Email</th> -->
                                        <th colspan="5">Actions</th>
                                    </tr>
                                    <?php $__currentLoopData = $AllEtudiant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CF): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <tr id="<?php echo e($CF->id); ?>">

                                            <td><?php  echo date('d/m/Y', strtotime($CF->DATE_INSCRIPTION)); ?> </td>
                                            <td > <?php echo e($CF->MATRICULE); ?> <d>
                                            <td > <?php echo e($CF->CIN_PASSPORT); ?> <d>
                                            <td > <?php echo e($CF->NOM_ETUDIANT); ?><d>
                                            <td >  <?php echo e($CF->PRENOM_ETUDIANT); ?><d>
                                            <td >  <?php echo e($CF->TEL); ?><d>
                                            <td> <?php echo ($CF->ACTIVE ==1) ? '<a href="'.route('DisableStudent',$CF->id).'"><span  class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>' : '<a href="'.route('EnableStudent',$CF->id).'"><span  class="glyphicon glyphicon-eye-close" aria-hidden="true"></span></a>'; ?></td>



                                            <td  ><a target="_blank"  href="" title="Imprimer fiche etudiant" class="glyphicon glyphicon-print" aria-hidden="true"></a></td>
                                            <td  data-toggle="modal" data-target="#ModalDetails<?php echo e($CF->id); ?>" data-whatever="@mdo" ><span title="Détails" class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"></span></td>
                                            <td  data-toggle="modal" data-target="#ModalEdit<?php echo e($CF->id); ?>" data-whatever="@mdo" ><span title="Modifier" class="glyphicon glyphicon-edit" aria-hidden="true"></span></td>
                                            <td  data-toggle="modal" data-target="#ModalDel<?php echo e($CF->id); ?>" data-whatever="@mdo" ><span title="Supprimer" class="glyphicon glyphicon-remove" aria-hidden="true"></span></td>
                                            <!----------->
                                            <div class="modal fade" id="ModalDetails<?php echo e($CF->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                                                <div class="modal-dialog" role="document">

                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                            <h4 class="modal-title" id="exampleModalLabel">Détails de l'étudiant <?php echo e($CF->NOM_ETUDIANT); ?> <?php echo e($CF->PRENOM_ETUDIANT); ?></h4>
                                                        </div>
                                                        <div class="modal-body">

                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="recipient-name" class="control-label">Date de naissance:</label>
                                                                <input disabled required onkeyup='this.value=this.value.toUpperCase()' type="text" class="form-control" value="<?php echo e($CF->DATE_NAISSANCE); ?>">
                                                            </div>
                                                                </div>

                                                                    <div class="col-lg-6">
                                                                    <div class="form-group">
                                                                <label for="recipient-name" class="control-label">Lieu:</label>
                                                                <input disabled required onkeyup='this.value=this.value.toUpperCase()' type="text" class="form-control"  value="<?php echo e($CF->LIEU); ?>">
                                                                    </div>
                                                                    </div>

                                                            </div>
                                                            <div class="row">

                                                                <div class="col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">NATIONALITE:</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control"  value="<?php echo e($CF->NATIONALITE); ?>">
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <div class="row">

                                                                <div class="col-lg-12">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">Adresse</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control"  value="<?php echo e($CF->ADRESSE); ?>">
                                                                    </div>
                                                                </div>


                                                            </div>



                                                            <div class="row">

                                                                <div class="col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">Ville</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control"  value="<?php echo e($CF->VILLE); ?>">
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">CP</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control"  value="<?php echo e($CF->CP); ?>">
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">Niveau scolaire:</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control"  value="<?php echo e($CF->NIVEAU_SCOLAIRE); ?>">
                                                                    </div>
                                                                </div>

                                                            </div>



                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">PRENOM_TUTEUR:</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control"  value="<?php echo e($CF->PRENOM_TUTEUR); ?>">
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">NOM_TUTEUR:</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control" name="NOM_TUTEUR" id="NOM_TUTEUR" value="<?php echo e($CF->NOM_TUTEUR); ?>">
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">TEL_TUTEUR:</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control"  value="<?php echo e($CF->TEL_TUTEUR); ?>">
                                                                    </div>
                                                                </div>

                                                                <div class="col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">EMAIL_TUTEUR:</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control" name="TOTAL" id="TOTAL" value="<?php echo e($CF->EMAIL_TUTEUR); ?>">
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <div class="form-group">
                                                                        <label for="message-text" class="control-label">Observation:</label>
                                                                        <input disabled required style="text-transform: capitalize" type="text" class="form-control"  value="<?php echo e($CF->OBSERVATION); ?>">
                                                                    </div>
                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                            <!------->



                                            <!----------->
                                            <div class="modal fade" id="ModalEdit<?php echo e($CF->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                                                <div class="modal-dialog" role="document">
                                                    <form action="UpdateStudent" method="post" name="CAT<?php echo e($CF->id); ?> " id="CAT<?php echo e($CF->id); ?>">
                                                        <?php echo e(csrf_field()); ?>

                                                        <input type="hidden" name="id" id="id" value="<?php echo e($CF->id); ?>">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                                <h4 class="modal-title" id="exampleModalLabel">Modifier l'étudiant N°<?php echo e($CF->id); ?></h4>
                                                            </div>


                                                            <div class="modal-body">

                                                                <div class="row">
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="recipient-name" class="control-label">Date d'inscription:</label>
                                                                            <input  required onkeyup='this.value=this.value.toUpperCase()' id="DATE_INSCRIPTION" name="DATE_INSCRIPTION" type="date" class="form-control" value="<?php echo e($CF->DATE_INSCRIPTION); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="recipient-name" class="control-label">Matricule:</label>
                                                                            <input  required onkeyup='this.value=this.value.toUpperCase()' id="MATRICULE" name="MATRICULE" type="text" class="form-control"  value="<?php echo e($CF->MATRICULE); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>


                                                                <div class="row">
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="recipient-name" class="control-label">Nom:</label>
                                                                            <input  required onkeyup='this.value=this.value.toUpperCase()' id="NOM_ETUDIANT" name="NOM_ETUDIANT" type="text" class="form-control" value="<?php echo e($CF->NOM_ETUDIANT); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="recipient-name" class="control-label">Prénom:</label>
                                                                            <input  required onkeyup='this.value=this.value.toUpperCase()' id="PRENOM_ETUDIANT" name="PRENOM_ETUDIANT" type="text" class="form-control"  value="<?php echo e($CF->PRENOM_ETUDIANT); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>


                                                                <div class="row">
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="recipient-name" class="control-label">Tel:</label>
                                                                            <input  required onkeyup='this.value=this.value.toUpperCase()' id="TEL" name="TEL" type="text" class="form-control" value="<?php echo e($CF->TEL); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="recipient-name" class="control-label">Email:</label>
                                                                            <input  required onkeyup='this.value=this.value.toUpperCase()' id="EMAIL" name="EMAIL" type="text" class="form-control"  value="<?php echo e($CF->EMAIL); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>




                                                                <div class="row">
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="recipient-name" class="control-label">Date de naissance:</label>
                                                                            <input  required onkeyup='this.value=this.value.toUpperCase()' id="DATE_NAISSANCE" name="DATE_NAISSANCE" type="text" class="form-control" value="<?php echo e($CF->DATE_NAISSANCE); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="recipient-name" class="control-label">Lieu:</label>
                                                                            <input  required onkeyup='this.value=this.value.toUpperCase()' id="LIEU" name="LIEU" type="text" class="form-control"  value="<?php echo e($CF->LIEU); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>


                                                                <div class="row">
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">CIN /PASSPORT:</label>
                                                                            <input   style="text-transform: capitalize" type="text" name="CIN_PASSPORT" id="CIN_PASSPORT" class="form-control"  value="<?php echo e($CF->CIN_PASSPORT); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">NATIONALITE:</label>
                                                                            <input  required style="text-transform: capitalize" type="text" id="NATIONALITE" name="NATIONALITE" class="form-control"  value="<?php echo e($CF->NATIONALITE); ?>">
                                                                        </div>
                                                                    </div>

                                                                </div>

                                                                <div class="row">

                                                                    <div class="col-lg-12">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">Adresse</label>
                                                                            <input  required style="text-transform: capitalize" type="text" class="form-control" id="ADRESSE" name="ADRESSE"  value="<?php echo e($CF->ADRESSE); ?>">
                                                                        </div>
                                                                    </div>


                                                                </div>



                                                                <div class="row">

                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">Ville</label>
                                                                            <input  required style="text-transform: capitalize" type="text" class="form-control" id="VILLE" name="VILLE"  value="<?php echo e($CF->VILLE); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">CP</label>
                                                                            <input  required style="text-transform: capitalize" type="text" class="form-control" name="CP" id="CP"  value="<?php echo e($CF->CP); ?>">
                                                                        </div>
                                                                    </div>

                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-lg-12">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">Niveau scolaire:</label>
                                                                            <input  required style="text-transform: capitalize" type="text" class="form-control" id="NIVEAU_SCOLAIRE" name="NIVEAU_SCOLAIRE" value="<?php echo e($CF->NIVEAU_SCOLAIRE); ?>">
                                                                        </div>
                                                                    </div>

                                                                </div>



                                                                <div class="row">
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">PRENOM_TUTEUR:</label>
                                                                            <input  required style="text-transform: capitalize" type="text" class="form-control" name="PRENOM_TUTEUR" id="PRENOM_TUTEUR" value="<?php echo e($CF->PRENOM_TUTEUR); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">NOM_TUTEUR:</label>
                                                                            <input  required style="text-transform: capitalize" type="text" class="form-control" name="NOM_TUTEUR" id="NOM_TUTEUR" value="<?php echo e($CF->NOM_TUTEUR); ?>">
                                                                        </div>
                                                                    </div>

                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">TEL_TUTEUR:</label>
                                                                            <input  required style="text-transform: capitalize" type="text" class="form-control" name="TEL_TUTEUR" id="TEL_TUTEUR" value="<?php echo e($CF->TEL_TUTEUR); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">EMAIL_TUTEUR:</label>
                                                                            <input  required style="text-transform: capitalize" type="text" class="form-control" name="EMAIL_TUTEUR" id="EMAIL_TUTEUR" value="<?php echo e($CF->EMAIL_TUTEUR); ?>">
                                                                        </div>
                                                                    </div>

                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-lg-12">
                                                                        <div class="form-group">
                                                                            <label for="message-text" class="control-label">Observation:</label>
                                                                            <input  style="text-transform: capitalize" type="text" class="form-control" name="OBSERVATION" id="OBSERVATION" value="<?php echo e($CF->OBSERVATION); ?>">
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <?php date_default_timezone_set('Africa/Tunis'); ?>
                                                            <input type="hidden" name="updated_at" value="<?php echo e(date('Y-m-d H:i:s')); ?>" />

                                                            <div class="modal-footer">
                                                                <button  class="btn btn-default"  data-dismiss="modal">Fermer</button>
                                                                <button  onclick="$('#CAT<?php echo $CF->id; ?> ').submit()"  class="btn btn-primary">Enregistrer</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <!----------->






















                                                <!----->
                                            <!----------->
                                            <div class="modal fade" id="ModalDel<?php echo e($CF->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                                                <div class="modal-dialog" role="document">
                                                    <form action="DelStudent" method="post" name="CATDel<?php echo e($CF->id); ?> " id="CAT<?php echo e($CF->id); ?>">
                                                        <?php echo e(csrf_field()); ?>

                                                        <input type="hidden" name="id" id="id" value="<?php echo e($CF->id); ?>">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                                <h4 class="modal-title" id="exampleModalLabel">Supprimer l'inscription N°<?php echo e($CF->id); ?></h4>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Voulez vous vraiment supprimer cet étudiant?</p>

                                                                <div class="alert alert-danger">
                                                                    <strong>Danger!</strong> Toutes les inscriptions pour cet étudiant seront supprimées.
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <input type="reset" class="btn btn-default" value="Fermer" data-dismiss="modal">
                                                                <input type="submit" onclick="$('#CATDel<?php echo $CF->id; ?> ').submit()"  class="btn btn-danger" value="Supprimer"/>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <!----------->
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                </table>
                                <?php echo e($AllEtudiant->links()); ?>


                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>




    <!------------------------>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>