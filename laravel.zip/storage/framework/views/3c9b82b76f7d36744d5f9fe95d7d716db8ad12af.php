<?php $__env->startSection('content'); ?>
    <div class="container">


        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                        <li><a href="#">Prestataires</a></li>
                        <li class="active">Ajouter prestataire</li>
                    </ol>
                </div>
            </div>



        <form id="" action="<?php echo e(route('SavePres')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-info ">

                    <div class="panel-heading"><strong>Nouveau préstataire:</strong> <span class="badge"><?php echo e(\App\prestataire::count()); ?> préstataire(s)</span> <a style="float: right" href="<?php echo e(route('ShowPres')); ?>" title="Ajouter un nouveau préstataire" class="glyphicon glyphicon-align-justify"></a> </div>

                    <div class="panel-body">
                        <div class="row">

                            <div class="col-lg-6">
                                <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">CODE</button>
                                </span>
                                    <input autofocus value="<?php echo e(isset($_POST['CODE'])?$_POST['CODE']:''); ?>" maxlength="10" style='text-transform:uppercase' tabindex="1" required id="CODE" name="CODE" type="text" class="form-control" placeholder="max 10 caractères">
                                </div><!-- /input-group -->
                            </div><!-- /.col-lg-6 -->

                            <div class="col-lg-6">
                                <div class="input-group">
                                <span class="input-group-btn">
                                    <label class="btn btn-default">Catégorie</label>
                                </span>
                                    <select   tabindex="2" required id="CATEGORIE" name="CATEGORIE" class="form-control" placeholder="">
                                    <?php $__currentLoopData = $AllCatPres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="<?php echo e($c->id); ?>"> <?php echo e($c->LIBELLE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                    </select>
                                </div><!-- /input-group -->
                            </div><!-- /.col-lg-6 -->

                        </div><!-- /.row -->
                        <br>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Nom</button>
                                </span>
                                    <input tabindex="3" style='text-transform:uppercase' required id="NOM" name="NOM" type="text" class="form-control" placeholder="">
                                </div><!-- /input-group -->
                            </div><!-- /.col-lg-6 -->

                        </div><!-- /.row -->

                        <br>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Adrresse</button>
                                </span>
                                    <input style='text-transform:uppercase' tabindex="9" required id="ADRESSE" name="ADRESSE" type="text" class="form-control" placeholder="">
                                </div><!-- /input-group -->
                            </div><!-- /.col-lg-6 -->

                        </div><!-- /.row -->
                        <br>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Ville</button>
                                </span>
                                    <input tabindex="11" style='text-transform:uppercase' required id="VILLE" name="VILLE" type="text" class="form-control" placeholder="">
                                </div><!-- /input-group -->
                            </div><!-- /.col-lg-6 -->
                            <div class="col-lg-6">
                                <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">CP</button>
                                </span>
                                    <input tabindex="12" required id="CP" name="CP" type="number" max="9999" maxlength="4" class="form-control" placeholder="">
                                </div><!-- /input-group -->
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                        <br>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="input-group">
                                <span class="input-group-btn">
                                    <button  class="btn btn-default" type="button">Tél</button>
                                </span>
                                    <input maxlength="8" tabindex="13"style='text-transform:uppercase' required id="TEL" name="TEL" type="tel" class="form-control" placeholder="">
                                </div><!-- /input-group -->
                            </div><!-- /.col-lg-6 -->
                            <div class="col-lg-6">
                                <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Email</button>
                                </span>
                                    <input tabindex="14" id="EMAIL" name="EMAIL" type="text" class="form-control" placeholder="">
                                </div><!-- /input-group -->
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->

                        <br>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="input-group">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Abservation</button>
                                </span>
                                    <textarea rows="5" style='text-transform:uppercase' tabindex="9" required id="OBSERVATION" name="OBSERVATION" class="form-control" placeholder=""></textarea>

                                </div><!-- /input-group -->
                            </div><!-- /.col-lg-6 -->

                        </div><!-- /.row -->





                    </div>
                </div>
            </div>
        </div>



<input type="hidden" name="created_at" value="<?php echo e(date('Y-m-d H:i:s')); ?>" />
            <input type="hidden" name="updated_at" value="<?php echo e(date('Y-m-d H:i:s')); ?>" />



            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="panel panel-danger  ">

                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-group">

                                    <input tabindex="26" type="submit" class="btn btn-danger"  value="Enregister ce prestataire"/>

                                    </div><!-- /input-group -->
                                </div><!-- /.col-lg-6 -->



                                <div class="col-lg-6">
                                    <div class="input-group">

                                        <input tabindex="27" type="reset" class="btn btn-success"  value="Effacer le formulaire"/>

                                    </div><!-- /input-group -->
                                </div><!-- /.col-lg-6 -->

                            </div><!-- /.row -->



                        </div>
                    </div>
                </div>
            </div>






        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>